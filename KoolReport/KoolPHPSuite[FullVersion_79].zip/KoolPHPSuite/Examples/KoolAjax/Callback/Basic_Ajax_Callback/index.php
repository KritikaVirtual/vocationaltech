<?php
	include("../../../../Resources/runexample.php");
	//Example source-code is stored nicely in example.php
?>
                           